// main.js

var config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 300 },
            debug: false
        }
    },
    scene: {
        preload: preload,
        create: create,
        update: update
    }
};

var player;
var stars;
var spikes;
var cursors;
var level = 1;
var levelText;
var gameOver = false;

var game = new Phaser.Game(config);

function preload() {
    this.load.image('sky', 'assets/sky.png');
    this.load.image('star', 'assets/star.png');
    this.load.image('elephant', 'assets/elephant.png'); // your new player sprite
    this.load.image('spikeball', 'assets/spikeball.png'); // the spike ball
}

function create() {
    this.add.image(400, 300, 'sky');

    player = this.physics.add.sprite(100, 450, 'elephant');
    player.setBounce(0.2);
    player.setCollideWorldBounds(true);

    stars = this.physics.add.group({
        key: 'star',
        repeat: 11,
        setXY: { x: 12, y: 0, stepX: 70 }
    });

    stars.children.iterate(function (child) {
        child.setGravityY(300); // gravity per star
    });

    spikes = this.physics.add.group({
        key: 'spikeball',
        repeat: 5,
        setXY: { x: 200, y: 0, stepX: 150 }
    });

    this.physics.add.collider(player, stars, collectStar, null, this);
    this.physics.add.collider(player, spikes, hitSpike, null, this);

    levelText = this.add.text(16, 16, 'Level: ' + level, {
        fontSize: '32px',
        fill: '#fff'
    });

    cursors = this.input.keyboard.createCursorKeys();
    cursors.space = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
}

function update() {
    if (gameOver) return;

    if (cursors.space.isDown && player.body.touching.down) {
        player.setVelocityY(-330);
    }

    if (stars.countActive(true) === 0) {
        level++;
        levelText.setText('Level: ' + level);
        stars.children.iterate(function (child) {
            child.enableBody(true, child.x, 0, true, true);
        });
    }
}

function collectStar(player, star) {
    star.disableBody(true, true);
}

function hitSpike(player, spike) {
    this.physics.pause();
    player.setTint(0xff0000);
    gameOver = true;
}
